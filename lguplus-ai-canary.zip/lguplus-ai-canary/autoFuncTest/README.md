##   Function Test Automation Script for LG U+ QnA System
